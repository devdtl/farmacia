<footer class="main-footer">
	
	<strong>Copyright &copy; 2022 <a href="#" target="_blank">Pinole.io</a>.</strong>

	Todos los derechos reservados.


</footer>